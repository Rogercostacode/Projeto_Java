/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.appbank;

/**
 *
 * @author F43535
 */
public class AppBank {

        public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new JLogin().setVisible(true);
        });
    }
}
